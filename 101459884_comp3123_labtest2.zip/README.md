# Weather App

## Project Details
This is the submission for the COMP3123 Lab Test 2.

### Student ID: 101459884

### Features:
- ReactJS app for displaying weather details.
- API Integration using OpenWeatherMap.
- State management with React hooks.
- Dynamic content updates with search functionality.

### Instructions:
1. Clone the repository from GitHub.
2. Run `npm install` to install dependencies.
3. Run `npm start` to launch the app.

## Submission Includes:
- ReactJS source code.
- Placeholders for screenshots (see DOCX).
- Postman response screenshots placeholder.

### GitHub Repository:
[Add your GitHub repository link here]

