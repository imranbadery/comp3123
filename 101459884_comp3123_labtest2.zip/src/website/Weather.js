
import React, { useEffect, useState } from "react";
import "./Weather.css";

const Weather = ({ city }) => {
  const [weatherData, setWeatherData] = useState(null);
  const [forecastData, setForecastData] = useState([]);
  const [loading, setLoading] = useState(false);
  const API_KEY = "your_api_key"; // Replace with your actual API key

  useEffect(() => {
    const fetchWeather = async () => {
      setLoading(true);
      try {
        const weatherResponse = await fetch(
          `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
        );
        const forecastResponse = await fetch(
          `http://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=metric`
        );

        const weatherData = await weatherResponse.json();
        const forecastData = await forecastResponse.json();

        setWeatherData(weatherData);
        setForecastData(
          forecastData.list.filter((item) => item.dt_txt.includes("12:00:00"))
        );
      } catch (error) {
        console.error("Error fetching weather data:", error);
      } finally {
        setLoading(false);
      }
    };

    if (city) fetchWeather();
  }, [city]);

  const getDayName = (dateString) => {
    const date = new Date(dateString);
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    return days[(date.getDay() + 6) % 7];
  };

  if (loading) return <p>Loading...</p>;
  if (!weatherData) return <p>No data found. Try another city.</p>;

  return (
    <div className="weather-container">
      <div className="weather-card">
        <h2>{weatherData.name}</h2>
        <h1>{weatherData.main.temp}°C</h1>
        <p>{weatherData.weather[0].description}</p>
      </div>
      <div className="forecast-container">
        <h3>5-Day Forecast</h3>
        <div className="forecast-grid">
          {forecastData.map((item, index) => (
            <div key={index} className="forecast-card">
              <p>{getDayName(item.dt_txt)}</p>
              <p>{item.main.temp}°C</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Weather;
