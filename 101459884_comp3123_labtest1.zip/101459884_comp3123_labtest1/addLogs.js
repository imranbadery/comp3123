// Module to create log files and directory
const fs = require('fs');
const path = require('path');

function generateLogFiles() {
    const logDir = path.join(__dirname, 'LogFiles');

    // Create log directory if it doesn't exist
    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir);
    }

    // Switch to the log directory
    process.chdir(logDir);

    // Create 10 log files
    for (let i = 1; i <= 10; i++) {
        const logFile = `logfile_${i}.txt`;
        fs.writeFileSync(logFile, `Log data for file ${i}`);
        console.log(`Created: ${logFile}`);
    }
}

// Call the function
generateLogFiles();
