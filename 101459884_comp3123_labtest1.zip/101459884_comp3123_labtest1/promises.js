// Promise that resolves after 500ms
function successPromise() {
    return new Promise((resolve) => {
        setTimeout(() => resolve("Success after 500ms"), 500);
    });
}

// Promise that rejects after 500ms
function failPromise() {
    return new Promise((_, reject) => {
        setTimeout(() => reject("Failed after 500ms"), 500);
    });
}

// Execute promises
successPromise()
    .then(successMsg => console.log(successMsg))  // Expected: "Success after 500ms"
    .catch(error => console.error(error));

failPromise()
    .then(successMsg => console.log(successMsg))
    .catch(error => console.error(error));  // Expected: "Failed after 500ms"
