// Function to filter strings and convert to lowercase
function makeWordsLowercase(inputArray) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(inputArray)) {
            reject("Provided input is not a valid array");
        } else {
            const filteredWords = inputArray.filter(element => typeof element === 'string')
                .map(word => word.toLowerCase());
            resolve(filteredWords);
        }
    });
}

// Testing the function
makeWordsLowercase(['HELLO', 42, 'WORLD', false, 'coding'])
    .then(result => console.log(result))  // Expected: ['hello', 'world', 'coding']
    .catch(error => console.error(error));
