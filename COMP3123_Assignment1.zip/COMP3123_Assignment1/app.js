const express = require('express');
const mongoose = require('mongoose');
const apiRoutes = require('./routes/api');

const app = express();

app.use(express.json());
app.use('/api/v1', apiRoutes);

mongoose.connect('mongodb://localhost/comp3123_assignment1', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB'))
    .catch(error => console.error('Error connecting to MongoDB', error));

app.listen(3000, () => console.log('Server running on port 3000'));
