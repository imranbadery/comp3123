// Import necessary libraries
const express = require("express");      // Express framework for web applications
const booksRoutes = require("./routes/books"); // Routes for book-related API endpoints
const mongoose = require("mongoose");     // Mongoose for MongoDB object modeling

// Initialize the Express application
const app = express();

// MongoDB connection string with a random password
const DB_CONNECTION_STRING = "mongodb+srv://101459884:Z9r3XkL7mQ$g1W8u@cluster0.hr7uu.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

// Connect to MongoDB
mongoose.connect(DB_CONNECTION_STRING, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => {
        console.log("Successfully connected to MongoDB"); // Log success message
    })
    .catch((err) => {
        console.error("Error connecting to MongoDB:", err); // Log error message
    });

// Define the server port
const SERVER_PORT = process.env.PORT || 3001; // Use the port from environment variable or default to 3001

// Middleware to parse JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set up routes for the API
app.use("/api/v1", booksRoutes);

// Root route for testing the server
app.get("/", (req, res) => {
    res.send("<h1>Welcome to the MongoDB + Mongoose Example!</h1>"); // Send a welcome message
});

// Start the server
app.listen(SERVER_PORT, () => {
    console.log(`Server is running at http://localhost:${SERVER_PORT}/`); // Log server status
});
